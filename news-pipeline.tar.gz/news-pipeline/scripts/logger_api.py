"""
score-logger — lightweight audit API
Receives POST requests from n8n with article scoring events and writes
structured logs to disk. Useful for debugging scoring thresholds and
reviewing what Claude decided about each article.

Endpoints:
  POST /log      — log a scoring/routing event
  GET  /recent   — return last N log entries as JSON
  GET  /health   — liveness check
"""

import json
import os
from datetime import datetime, timezone
from flask import Flask, request, jsonify

app = Flask(__name__)
LOG_DIR = os.environ.get("LOG_DIR", "/app/logs")
LOG_FILE = os.path.join(LOG_DIR, "pipeline.jsonl")

os.makedirs(LOG_DIR, exist_ok=True)


def _write(entry: dict):
    entry["ts"] = datetime.now(timezone.utc).isoformat()
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


@app.route("/log", methods=["POST"])
def log_event():
    """
    Expected payload:
    {
        "event":   "scored" | "published" | "review" | "archived",
        "title":   "Article title",
        "url":     "https://...",
        "score":   8,
        "reason":  "Claude's scoring rationale",
        "niche":   "cybersecurity"
    }
    """
    data = request.get_json(silent=True) or {}
    if not data:
        return jsonify({"error": "empty payload"}), 400
    _write(data)
    return jsonify({"logged": True}), 200


@app.route("/recent", methods=["GET"])
def recent():
    n = int(request.args.get("n", 50))
    if not os.path.exists(LOG_FILE):
        return jsonify([]), 200
    with open(LOG_FILE) as f:
        lines = f.readlines()
    entries = []
    for line in lines[-n:]:
        try:
            entries.append(json.loads(line.strip()))
        except json.JSONDecodeError:
            pass
    return jsonify(list(reversed(entries))), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)
