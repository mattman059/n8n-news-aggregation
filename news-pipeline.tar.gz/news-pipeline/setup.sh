#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# setup.sh — first-run setup for news-pipeline
# Run once before `docker compose up`
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; NC='\033[0m'

info()  { echo -e "${GREEN}[+]${NC} $*"; }
warn()  { echo -e "${YELLOW}[!]${NC} $*"; }
error() { echo -e "${RED}[✗]${NC} $*" >&2; exit 1; }

# ── 1. Check dependencies ─────────────────────────────────────────────────────
command -v docker      &>/dev/null || error "docker not found"
command -v docker      &>/dev/null && docker compose version &>/dev/null || \
  command -v docker-compose &>/dev/null || error "docker compose / docker-compose not found"

# ── 2. Copy env template ──────────────────────────────────────────────────────
if [[ ! -f .env ]]; then
  cp .env.example .env
  warn ".env created from template — edit it before continuing"
  warn "  Required: ANTHROPIC_API_KEY, GOOGLE_SPREADSHEET_ID"
  echo ""
  read -rp "Press ENTER after editing .env to continue, or Ctrl+C to abort..." _
fi

source .env

# ── 3. Validate required vars ─────────────────────────────────────────────────
[[ -z "${ANTHROPIC_API_KEY:-}" ]]      && error "ANTHROPIC_API_KEY is not set in .env"
[[ -z "${GOOGLE_SPREADSHEET_ID:-}" ]]  && error "GOOGLE_SPREADSHEET_ID is not set in .env"

# ── 4. Check Google credentials ───────────────────────────────────────────────
if [[ ! -f config/google-credentials.json ]]; then
  warn "config/google-credentials.json not found"
  warn "Create a Google Cloud service account, enable Sheets API, download the key JSON,"
  warn "save it as config/google-credentials.json, and share your spreadsheet with the"
  warn "service account email (editor access)."
  warn "See README.md for step-by-step instructions."
  echo ""
  read -rp "Press ENTER once credentials are in place, or Ctrl+C to abort..." _
fi

# ── 5. Create directories ─────────────────────────────────────────────────────
info "Creating runtime directories..."
mkdir -p n8n-data logs config

# ── 6. Set n8n data permissions (n8n runs as UID 1000) ────────────────────────
if [[ "$(id -u)" != "0" ]]; then
  warn "Not running as root — if n8n has permission errors, run: sudo chown -R 1000:1000 n8n-data"
fi
chmod -R 777 n8n-data 2>/dev/null || true

# ── 7. Pull images ────────────────────────────────────────────────────────────
info "Pulling Docker images..."
docker compose pull

# ── 8. Start stack ────────────────────────────────────────────────────────────
info "Starting stack..."
docker compose up -d

echo ""
info "Stack is up!"
echo ""
echo "  n8n UI:       http://localhost:5678"
echo "  Score logger: http://localhost:5001/recent"
echo ""
echo "Next steps:"
echo "  1. Log into n8n at http://localhost:5678"
echo "  2. Go to Settings > Credentials and add:"
echo "     - Anthropic API (paste your key)"
echo "     - Google Sheets OAuth2 (service account JSON)"
echo "  3. Import workflow: Settings > Import from file > workflow.json"
echo "  4. Activate the workflow"
echo ""
info "Done."
