# News Intelligence Pipeline

n8n + Claude (Anthropic) + Google Sheets — automated news scoring, analysis, and triage.

## Architecture

```
RSS Feeds
    │
    ▼
Normalize Article         ← standardize fields across feed formats
    │
    ▼
Scoring AI (Claude)       ← scores article 1–10 for niche relevance
    │
    ▼
Parse Score               ← extracts JSON from Claude response
    │
    ├──────────────────── Audit Log (score-logger sidecar)
    │
    ▼
Quality Filter 1 (score >= 7?)
    │ YES                    NO
    ▼                        ▼
Content AI (Claude)     Quality Filter 2 (score >= 4?)
analysis report              │ YES          NO
    │                        ▼              ▼
    ▼                   For Review       Archive
Published Sheet         Sheet            Sheet
```

## Stack

| Service        | Image               | Port | Purpose                  |
|----------------|---------------------|------|--------------------------|
| `n8n`          | n8nio/n8n:latest    | 5678 | Workflow engine + UI     |
| `redis`        | redis:7-alpine      | —    | n8n state/queue cache    |
| `score-logger` | python:3.11-slim    | 5001 | Audit log REST API       |

---

## Prerequisites

- Docker + Docker Compose v2
- Anthropic API key: https://console.anthropic.com/
- Google Cloud service account with Sheets API enabled

---

## Quick Start

```bash
bash setup.sh
```

The script handles env setup, image pulls, and stack startup. Follow the prompts.

---

## Google Sheets Setup

### 1. Service Account

1. https://console.cloud.google.com/ → create/select a project
2. Enable **Google Sheets API**
3. IAM & Admin → Service Accounts → Create → download JSON key
4. Save as `config/google-credentials.json`

### 2. Spreadsheet

Create a Google Sheet with three tabs:
- `Published`
- `For Review`
- `Archive`

**Published** headers (Row 1):
```
Date | Score | Title | Headline | URL | Source | Tags | TLDR | Analysis | So What | Action Items | Processed At
```

**For Review** headers:
```
Date | Score | Title | URL | Source | Tags | TLDR | Reason
```

**Archive** headers:
```
Date | Score | Title | URL | Source | Reason
```

Share the spreadsheet with the service account's `client_email` (Editor access).

Copy the spreadsheet ID from the URL and set it in `.env` as `GOOGLE_SPREADSHEET_ID`.

---

## n8n Credential Setup

After stack starts, go to http://localhost:5678.

**Anthropic:**
Settings → Credentials → New → Anthropic → paste API key → name it `Anthropic API`

**Google Sheets:**
Settings → Credentials → New → Google Sheets → Service Account → paste JSON contents → name it `Google Sheets`

**Import workflow:**
Workflows → Import from File → select `workflow.json` → activate

---

## Configuration (.env)

```bash
N8N_USER=admin
N8N_PASSWORD=strong_password
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_SPREADSHEET_ID=your_id
SHEET_PUBLISHED=Published
SHEET_REVIEW=For Review
SHEET_ARCHIVE=Archive
SCORE_PUBLISH_MIN=7
SCORE_REVIEW_MIN=4
RSS_FEEDS=https://feeds.feedburner.com/TheHackersNews,...
TIMEZONE=America/Chicago
```

---

## Useful Commands

```bash
# Start
docker compose up -d

# Logs
docker compose logs -f n8n

# Recent scoring decisions
curl -s http://localhost:5001/recent | jq '.[] | {title, score, event}'

# Stop
docker compose down

# Full wipe
docker compose down -v && rm -rf n8n-data logs
```

---

## Extending

**Deduplication:** Add a Redis node before Scoring AI — check/set `seen:<url_hash>` with 7-day TTL.

**Multi-feed:** Duplicate the RSS Feed Trigger node for each feed URL; merge all outputs into Normalize Article.

**Telegram alerts:** Add an HTTP Request node after "Log to Review Sheet" POSTing to your bot webhook.

**Local model:** Replace Anthropic credential with an Ollama HTTP Request node at `http://host.docker.internal:11434`.
